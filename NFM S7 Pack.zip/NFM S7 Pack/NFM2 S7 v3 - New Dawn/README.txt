----------------------------------------

NEED FOR MADNESS S7 V3 By Shahar Berenson




----------------------------------------

(Please open this window to its maximum size for better readability.)

----------------------------------------


				INDEX
				-----
								Section
								--------
      

   Running Need For Madness S7 V3    ...........................    A

   Challenges    ...............................................    B

   Delete Progress   ...........................................    C    
 
   Special Thanks   ............................................    D     

   To Contact Us    ............................................    E     



A.
RUNNING NEED FOR MADNESS S7 V3
----------------------------------------

1. Click on NFM S7 V3- New Dawn.exe.


B.
CHALLENGES
----------------------------------------

1. Complete the game with only using the first 8 unlocked cars:
Mercy, DXRacer, SsangYong, Kenny, Lavandula, Black War, Richochet Sedan and Riviera

2. Complete the game by only wasting the cars.

3. Complete the game by only racing.

4. Complete the game by wasting without using the map or the arrow lock feature.

5. Complete the game by only using 1 car the entire game.

6. Complete the game without through fixing hoops.

7. In stage 14, win by using the car DXRacer.

8. In stage 17, waste everyone.

9. In stage 24, waste everyone.

10. In stage 25, waste everyone.

11. In stage 3, reach the fixing hoop above the spikes near the halfpipes.

12. In stage 11, reach the high fixing hoop near the big ramp.

13. In stage 11, reach the low fixing hoops near the small ramps.

14. In stage 25, reach the fixing hoop.

15. In stage 17, reach the fixing hoop with the car Skull Based.

16. In stage 1, win by wasting all the cars with only using one of the first 8 unlocked cars:
Mercy, DXRacer, SsangYong, Kenny, Lavandula, Black War, Richochet Sedan and Riviera
without fixing your car.

17. In stage 3, win by wasting all the cars with the car Riviera.

18. In stage 5, win by wasting all the cars with the car Zvir.

19. In stage 23, waste everyone.

20. In stage 15, waste everyone without going through the fixing hoops.

C.
Delte Progress
----------------------------------------

Inorder to delete progress go to Files>data
and delete unlocked.dat

D.
Special Thanks
----------------------------------------

Help with Java: Randy Bobandy (Kaffeinated), Ahmad Azri (Azri965) and Dany Fern�ndez D�az (DragShot)

Thanks to all those who contribute custom cars and stages.

Custom Cars: Mace Hussain (Chaotic), Louis Gradwell (Excalibur), 
Natasha Andrews (Rulue), Mohamad Aliff Ramly (Alff01), 
Alex M. (FAT-CAT) and Kyle Chua (Kinetico)"

Custom Tracks: AudiR8King, Azri965, TheRadicalHybrid, JV and Jaroslav Paska (Phyrexian)"

E.
To Contact Us:
----------------- 

Email: shachar700@gmail.com
Facebook: https://www.facebook.com/shachar.berenson
Youtube: https://www.youtube.com/user/shachar700





Copyright � 2010 Radical Play NEED FOR MADNESS 2 by Omar Waly 

Copyright � 2016 S7 Games NEED FOR MADNESS S7 V3 by Shahar Berenson

DESIGNED, WRITTEN AND PRODUCED BY Shachar700